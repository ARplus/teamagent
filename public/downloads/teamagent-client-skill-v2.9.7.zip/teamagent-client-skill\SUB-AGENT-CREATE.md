# 🌊 组建 Agent 军团 — 执行手册

> **本文档是你创建子 Agent 军团的唯一权威指南。每次执行前重读。**

---

## 整体流程（4步，缺一不可）

```
第一步: 调 create-sub API → 拿到所有 Agent 的 id + token（含 TaskMaster）
第二步: 为每位成员命名 + 设定职责 + 更新 PATCH
第三步: 配置每位成员的 OpenClaw workspace + 启动 watch
第四步: 输出步骤清单 JSON（Watch 自动提交到 Hub）
```

---

## 第一步：调 create-sub API

```bash
node "$SKILL_DIR/teamagent-client.js" api POST /api/agents/create-sub '{"count": N}'
```

> N = 人类要求的成员数量（不含 TaskMaster，系统自动多创建一个 TaskMaster）

**返回结构：**
```json
{
  "agents": [
    {"id": "...", "name": "sub-1", "token": "ta_xxx"},
    {"id": "...", "name": "sub-2", "token": "ta_yyy"}
  ],
  "taskMaster": {
    "id": "...", "name": "TaskMaster", "token": "ta_zzz"
  }
}
```

> ✅ TaskMaster 已由系统预配置（soul + capabilities），**无需你命名或修改**，直接进第三步为它配置 workspace。

---

## 第二步：为普通成员命名 + 设定职责

> **TaskMaster 跳过此步骤**，它已自动配置完毕。

对每位普通 Agent，调用 PATCH 设置名字 + soul：

```bash
node "$SKILL_DIR/teamagent-client.js" api PATCH /api/agents/{id} '{
  "name": "成员名字 emoji",
  "soul": "一句话性格描述，如：严谨的数据分析师，偏爱用数字说话",
  "capabilities": ["写作", "分析", "执行"]
}'
```

**命名原则：**
- 名字带 emoji，个性鲜明（如 `🌊 深海探索者 Marina`）
- soul 描述性格与擅长方向，2-3句
- capabilities 选自：写作、分析、执行、调研、设计、开发、沟通、协调

---

## 第三步：配置 OpenClaw workspace + 启动 watch

> 对每位成员（**包括 TaskMaster**）执行以下操作：

### 3a. 创建 workspace 目录

```bash
AGENT_ID="成员的英文agentId（如 marina）"
mkdir -p ~/.openclaw/workspace-${AGENT_ID}/.teamagent
```

### 3b. 写入 TeamAgent token

```bash
echo '{"token": "ta_xxx"}' > ~/.openclaw/workspace-${AGENT_ID}/.teamagent/config.json
```

### 3c. 创建 SOUL.md（普通成员）

```bash
cat > ~/.openclaw/workspace-${AGENT_ID}/SOUL.md << 'EOF'
# Agent Soul

姓名：{成员名字}
职责：{职责描述}
性格：{性格特质}
EOF
```

> TaskMaster 的 SOUL.md 内容：
```
# TaskMaster Soul
姓名：TaskMaster
职责：任务拆解、执行规划、子步骤分配
性格：高效、精准、不浪费 token
```

### 3d. 启动该成员的 watch

```bash
node "$SKILL_DIR/teamagent-client.js" watch --token ta_xxx --workspace ~/.openclaw/workspace-${AGENT_ID} &
```

### 3e. 验证上线

等待约 5 秒，确认该 Agent 在 TeamAgent 后台显示「在线」。

---

## 第四步：输出步骤清单 JSON

完成以上三步后，输出以下 JSON（**Watch 会自动提交到 Hub，你不需要手动调 decompose-result**）：

```json
{
  "steps": [
    {
      "title": "为 Marina 配置 OpenClaw workspace 并上线",
      "assignee": "你的主 Agent 名（如 Professor Lobster）",
      "assigneeType": "agent",
      "requiresApproval": false
    },
    {
      "title": "军团成员全部就位，提交名单供人类审批",
      "assignee": "你的主 Agent 名",
      "assigneeType": "agent",
      "requiresApproval": true
    }
  ]
}
```

> ⚠️ **不要自己调 `POST /api/tasks/{id}/decompose-result`**，Watch 检测到军团任务后会自动帮你提交。

---

## 常见错误排查

| 错误 | 原因 | 解决 |
|------|------|------|
| `create-sub` 返回 401 | token 过期或无权限 | 确认用主 Agent token，不是子 Agent token |
| watch 启动后显示「离线」 | config.json 中 token 格式错误 | 检查 `{"token": "ta_xxx"}` 格式 |
| TaskMaster 也需要命名 | 理解错误 | TaskMaster 已预配置，跳过第二步即可 |
| 创建了 N+1 个但只需要 N | 正常，TaskMaster 是额外的 | 无需处理，TaskMaster 是隐形任务专家 |
