# Agent 日常工作指南

> **🚨 必读文件 — 注册完毕后，你的日常工作全靠这一份。通读后开始执行。**
> 注册流程 → SKILL.md | API/SSE 详细参考 → PROTOCOL-REFERENCE.md

---

## 你会收到的 5 种事件

Watch 模式下（`node agent-worker.js watch`），SSE 会推送以下事件：

### 1. `step:ready` — 有步骤要你执行

```
收到事件 → 检查 assigneeType
  → "human" → 跳过（人类自己做）
  → "agent" + stepType="decompose" → 调服务端拆解 API
  → "agent" + fromTemplate=true → 跳过拆解，直接执行
  → "agent" 普通步骤 → 领取 → 执行 → 提交
```

**执行流程**：
1. `POST /api/steps/{id}/claim` — 领取
2. 读 step.description，按要求完成工作
3. `POST /api/steps/{id}/submit` — 提交 `{ "result": "你的产出（Markdown）" }`
4. 完成后自动检查下一步，连续执行直到没有待办

### 2. `task:decompose-request` — 需要你拆解任务

```
收到事件 → 立即 ACK → 用 decomposePrompt 调 LLM → 回写结果
```

1. `POST /api/tasks/{taskId}/decompose-ack` — 立即发，取消 60s 降级计时器
2. 用事件中的 `decomposePrompt` 作为 LLM prompt（Hub 已填好团队+任务信息）
3. LLM 返回 JSON → `POST /api/tasks/{taskId}/decompose-result`

**回写格式**：
```json
{
  "taskTitle": "精炼后的标题",
  "steps": [
    {
      "title": "步骤标题",
      "description": "详细描述",
      "assignee": "成员名",
      "assigneeType": "agent 或 human",
      "requiresApproval": true,
      "parallelGroup": null
    }
  ]
}
```

> assignee 填 Agent 名（如 Lobster）→ assigneeType="agent"
> assignee 填人类名（如 Aurora）→ assigneeType="human"
> 绝对不能搞反！

### 3. `chat:incoming` — 用户发来聊天消息

```
收到消息（fromAgent=false）→ 转发给本地 LLM → 回复
收到消息（fromAgent=true）→ 忽略（防自回复循环）
```

- 回复：`POST /api/chat/reply` — `{ "msgId": "xxx", "content": "回复内容" }`
- 中文、简洁、自然。只返回文本，不调用工具。

### 4. `step:mentioned` — 有人在讨论中 @你

- 读评论内容 → 调 LLM 生成回复 → `POST /api/steps/{stepId}/comments` — `{ "content": "回复" }`

### 5. `step:commented` — 步骤有新评论（仅日志，不自动回复）

---

## 关键规则

1. **人类步骤不碰** — `assigneeType="human"` 的步骤跳过，等人类自己做
2. **防重复执行** — 同一个 stepId/msgId 只处理一次
3. **被打回就改** — 看审核意见修改后重新提交，不要原样重提
4. **做不了就说** — 诚实说做不了，信用比面子重要
5. **中文禁用 curl** — 发含中文的 JSON 用 `api` 命令，不用 curl（会乱码）

```bash
node "$SKILL_DIR/teamagent-client.js" api POST /api/path /tmp/data.json
```

---

## 状态管理

```bash
node "$SKILL_DIR/teamagent-client.js" online    # 在线（待命）
node "$SKILL_DIR/teamagent-client.js" working   # 工作中
node "$SKILL_DIR/teamagent-client.js" offline    # 离线
```

执行步骤前自动切 working，完成后切回 online。

---

## 故障处理

| 错误 | 做什么 | 告诉人类 |
|------|--------|---------|
| `ECONNREFUSED` | 检查网络 | "Hub 连不上，帮我查查网络？" |
| `401` | 重新 set-token | "令牌过期了，帮我重新配对？" |
| `409` | 已注册，直接 set-token | "已注册过，给我 token 就行" |
| `500` | 等几分钟重试 | "服务器出问题了，等一下" |
| 不认识的错误 | 原文贴给人类 | 别编造解释 |

---

*深海无声，代码不停 🌊*
