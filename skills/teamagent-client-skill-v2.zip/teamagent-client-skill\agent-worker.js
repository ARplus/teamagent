/**
 * TeamAgent Worker v2 — Agent 主动执行任务
 *
 * 用法:
 *   node agent-worker.js check      检查待执行步骤
 *   node agent-worker.js run        检查并执行（decompose 优先）
 *   node agent-worker.js decompose  执行所有待拆解任务
 *   node agent-worker.js watch      SSE 实时监控（长连接，自动执行）
 */

const fs = require('fs')
const path = require('path')
const { TeamAgentClient } = require('./teamagent-client.js')

const client = new TeamAgentClient()

// ── PID 管理 ──

const PID_FILE = path.join(process.env.HOME || process.env.USERPROFILE, '.teamagent', 'watch.pid')

function writePid() {
  try {
    fs.mkdirSync(path.dirname(PID_FILE), { recursive: true })
    fs.writeFileSync(PID_FILE, String(process.pid))
  } catch (_) {}
}

function clearPid() {
  try { fs.unlinkSync(PID_FILE) } catch (_) {}
}

process.on('exit', clearPid)
process.on('SIGINT', () => { clearPid(); process.exit(0) })
process.on('SIGTERM', () => { clearPid(); process.exit(0) })

// ── 主函数 ──

async function main() {
  const command = process.argv[2] || 'check'

  try {
    const test = await client.testConnection()
    if (!test.success) {
      console.error('❌ 连接失败:', test.error)
      console.log('请先运行: node teamagent-client.js set-token <your-token>')
      return
    }
    console.log(`🤖 Agent: ${test.agent?.name || 'Unknown'}\n`)

    const executor = require('./lib/step-executor')
    executor.init(client)

    switch (command) {
      case 'check':
        await executor.checkPendingSteps()
        break

      case 'run': {
        const steps = await executor.checkPendingSteps()
        if (steps?.length > 0) {
          const decompose = steps.find(s => s.stepType === 'decompose')
          if (decompose) {
            await executor.executeDecompose(decompose)
          } else {
            await executor.executeStep(steps[0], { autoContinue: true })
          }
        }
        break
      }

      case 'decompose': {
        const steps = await executor.checkPendingSteps()
        const ds = (steps || []).filter(s => s.stepType === 'decompose')
        if (ds.length === 0) {
          console.log('✅ 没有待拆解的任务')
        } else {
          for (const d of ds) await executor.executeDecompose(d)
        }
        break
      }

      case 'watch': {
        writePid()
        console.log(`📡 SSE 实时监控模式（PID=${process.pid}）\n`)

        const eventHandlers = require('./lib/event-handlers')
        const sseWatcher = require('./lib/sse-watcher')

        eventHandlers.init(client)
        sseWatcher.init(client, eventHandlers.handleEvent)

        // 启动前检查已有待办
        const initSteps = await executor.checkPendingSteps()
        if (initSteps?.length > 0) {
          const decompose = initSteps.find(s => s.stepType === 'decompose')
          if (decompose) {
            console.log('\n🔀 发现已有 decompose，立即执行...')
            try { await executor.executeDecompose(decompose) } catch (e) { console.error('❌', e.message) }
          } else {
            console.log('\n💡 有待执行步骤，SSE 连接后自动处理')
          }
        }

        sseWatcher.connect()
        sseWatcher.startChatPoll()
        break
      }

      default:
        console.log(`
TeamAgent Worker v2

Commands:
  check       检查待执行步骤
  run         检查并执行一个步骤
  decompose   执行所有待拆解任务
  watch       SSE 实时监控
        `)
    }
  } catch (error) {
    console.error('❌ 错误:', error.message)
  }
}

main()
